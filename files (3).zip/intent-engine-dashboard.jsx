import { useState, useEffect, useRef, useCallback } from "react";

// ════════════════════════════════════════════════════════════════
//  INTENT ENGINE — pure deterministic math, no API
// ════════════════════════════════════════════════════════════════

const EVENT_CATALOG = {
  // HIGH INTENT
  demo_request:          { w:50, tier:"H", label:"Demo Requested",       icon:"🎯" },
  trial_start:           { w:45, tier:"H", label:"Trial Started",        icon:"🚀" },
  pricing_page_visit:    { w:22, tier:"H", label:"Pricing Page Visit",   icon:"💰" },
  contact_sales_click:   { w:38, tier:"H", label:"Contacted Sales",      icon:"📞" },
  product_comparison:    { w:30, tier:"H", label:"Compared Products",    icon:"⚖️" },
  checkout_start:        { w:48, tier:"H", label:"Started Checkout",     icon:"🛒" },
  roi_calculator:        { w:28, tier:"H", label:"Used ROI Calculator",  icon:"📊" },
  contract_view:         { w:35, tier:"H", label:"Viewed Contract",      icon:"📋" },
  // MEDIUM INTENT
  case_study_view:       { w:12, tier:"M", label:"Read Case Study",      icon:"📖" },
  webinar_attended:      { w:14, tier:"M", label:"Attended Webinar",     icon:"🎙️" },
  whitepaper_download:   { w:10, tier:"M", label:"Downloaded Whitepaper",icon:"📄" },
  feature_page_view:     { w:8,  tier:"M", label:"Browsed Features",     icon:"🔍" },
  integration_page:      { w:11, tier:"M", label:"Checked Integrations", icon:"🔌" },
  email_reply:           { w:15, tier:"M", label:"Replied to Email",     icon:"✉️" },
  video_watch:           { w:7,  tier:"M", label:"Watched Demo Video",   icon:"▶️" },
  api_docs_view:         { w:9,  tier:"M", label:"Read API Docs",        icon:"</>" },
  email_click:           { w:6,  tier:"M", label:"Clicked Email Link",   icon:"🔗" },
  trial_login:           { w:5,  tier:"M", label:"Product Login",        icon:"🔐" },
  // LOW INTENT
  blog_read:             { w:2,  tier:"L", label:"Read Blog",            icon:"📰" },
  email_open:            { w:2,  tier:"L", label:"Opened Email",         icon:"📬" },
  page_view:             { w:1,  tier:"L", label:"Page View",            icon:"👁" },
  homepage_visit:        { w:1,  tier:"L", label:"Homepage Visit",       icon:"🏠" },
};

const TIER_COLOR = { H:"#ff3d6b", M:"#ffcb47", L:"#4a7a9b" };

function recencyDecay(daysAgo, halfLifeDays=14) {
  return Math.exp(-daysAgo * Math.log(2) / halfLifeDays);
}

function computeIntentFeatures(events) {
  const now = Date.now();
  const W7D  = 7  * 86400000;
  const W30D = 30 * 86400000;

  let rawScore=0, hi7=0, hi30=0, sessions7=0, sessions30=0;
  let prisingVisits7=0, demoReq7=0, salesClicks7=0, trialEvents7=0;
  let caseStudy30=0, webinar30=0, emailReply30=0, intPage30=0;
  let lastHighIntentAge=999, lastPricingAge=999, lastDemoAge=999, lastActivityAge=999;
  let totalHigh=0, totalMed=0, totalLow=0;
  const seqBuffer = [];

  // Prev-week sessions for acceleration
  const W14D = 14 * 86400000;
  let prevWeekSessions=0;

  for (const e of events) {
    const ts  = new Date(e.occurred_at).getTime();
    const age = (now - ts) / 86400000;
    const ageMs = now - ts;
    const cfg = EVENT_CATALOG[e.event_type];
    if (!cfg) continue;

    const decay = recencyDecay(age);
    rawScore += cfg.w * decay;

    if (ageMs <= W30D) {
      sessions30++;
      if (cfg.tier==="H") { hi30++; totalHigh++; }
      if (cfg.tier==="M") totalMed++;
      if (cfg.tier==="L") totalLow++;
      if (e.event_type==="case_study_view")    caseStudy30++;
      if (e.event_type==="webinar_attended")   webinar30++;
      if (e.event_type==="email_reply")        emailReply30++;
      if (e.event_type==="integration_page")   intPage30++;
    }
    if (ageMs <= W7D) {
      sessions7++;
      if (cfg.tier==="H") hi7++;
      if (e.event_type==="pricing_page_visit")  prisingVisits7++;
      if (e.event_type==="demo_request")         demoReq7++;
      if (e.event_type==="contact_sales_click")  salesClicks7++;
      if (["trial_start","checkout_start"].includes(e.event_type)) trialEvents7++;
    }
    if (ageMs > W7D && ageMs <= W14D) prevWeekSessions++;

    // Recency tracking
    if (age < lastActivityAge) lastActivityAge = age;
    if (cfg.tier==="H" && age < lastHighIntentAge) lastHighIntentAge = age;
    if (e.event_type==="pricing_page_visit" && age < lastPricingAge) lastPricingAge = age;
    if ((e.event_type==="demo_request"||e.event_type==="contact_sales_click") && age < lastDemoAge) lastDemoAge = age;

    seqBuffer.push(e.event_type);
  }

  const total = totalHigh + totalMed + totalLow || 1;
  const baselinePerWeek = sessions30 / 4;
  const engVelocity = Math.min(5, sessions7 / Math.max(baselinePerWeek, 0.01));
  const hiVelocity  = Math.min(5, hi7 / Math.max(hi30/4, 0.01));
  const acceleration = Math.min(3, (sessions7 - prevWeekSessions) / Math.max(prevWeekSessions, 1));

  // Sequence detection
  const detectSeq = (a, b, gap=20) => {
    let lastA = -999;
    for (let i=0; i<seqBuffer.length; i++) {
      if (seqBuffer[i]===a) lastA=i;
      else if (seqBuffer[i]===b && (i-lastA)<=gap) return true;
    }
    return false;
  };

  const seqs = {
    blog_to_pricing:       detectSeq("blog_read","pricing_page_visit"),
    pricing_to_demo:       detectSeq("pricing_page_visit","demo_request"),
    case_study_to_pricing: detectSeq("case_study_view","pricing_page_visit"),
    trial_to_pricing:      detectSeq("trial_login","pricing_page_visit"),
    multi_session_pricing: seqBuffer.filter(e=>e==="pricing_page_visit").length >= 3,
  };

  return {
    rawScore: Math.min(1, rawScore/1000),
    demoReq7, prisingVisits7, salesClicks7, trialEvents7,
    caseStudy30, webinar30, emailReply30, intPage30,
    sessions7, sessions30, prevWeekSessions,
    engVelocity, hiVelocity, acceleration,
    lastHighIntentAge, lastPricingAge, lastDemoAge, lastActivityAge,
    seqs,
    highPct:  totalHigh/total,
    medPct:   totalMed/total,
    lowPct:   totalLow/total,
  };
}

function computeIntentScore(f) {
  let s = 0;
  s += Math.min(1.0,  f.demoReq7        * 0.40);
  s += Math.min(0.85, f.trialEvents7    * 0.50);
  s += Math.min(0.75, f.salesClicks7    * 0.35);
  s += Math.min(0.65, f.prisingVisits7  * 0.18);
  s += Math.min(0.20, f.caseStudy30     * 0.05);
  s += Math.min(0.18, f.webinar30       * 0.06);
  s += Math.min(0.15, f.emailReply30    * 0.06);
  s += 0.50 * (f.seqs.pricing_to_demo       ? 1:0);
  s += 0.35 * (f.seqs.case_study_to_pricing ? 1:0);
  s += 0.25 * (f.seqs.trial_to_pricing      ? 1:0);
  s += 0.20 * (f.seqs.multi_session_pricing ? 1:0);
  const velBoost = Math.min(1.3, 0.8 + 0.1 * f.engVelocity);
  s *= velBoost;
  if (f.lastActivityAge > 30) s *= Math.exp(-(f.lastActivityAge-30)/30);
  return Math.min(1, Math.max(0, s));
}

function fusedScore(convProb, intentProb, w={conv:0.60, intent:0.40}) {
  return Math.min(1, w.conv*convProb + w.intent*intentProb);
}

// ─── Data generation ───
function rng(seed) {
  let s=seed>>>0;
  return ()=>{s=(Math.imul(1664525,s)+1013904223)>>>0;return s/0x100000000;};
}

const ALL_EVENTS = Object.keys(EVENT_CATALOG);
const HIGH_EVENTS = ALL_EVENTS.filter(k=>EVENT_CATALOG[k].tier==="H");
const MED_EVENTS  = ALL_EVENTS.filter(k=>EVENT_CATALOG[k].tier==="M");
const LOW_EVENTS  = ALL_EVENTS.filter(k=>EVENT_CATALOG[k].tier==="L");

function pickEvent(r) {
  const roll = r();
  if (roll < 0.12) return HIGH_EVENTS[Math.floor(r()*HIGH_EVENTS.length)];
  if (roll < 0.42) return MED_EVENTS[Math.floor(r()*MED_EVENTS.length)];
  return LOW_EVENTS[Math.floor(r()*LOW_EVENTS.length)];
}

function generateLeadEvents(seed, nEvents) {
  const r = rng(seed);
  const now = Date.now();
  return Array.from({length:nEvents}, () => ({
    event_type:  pickEvent(r),
    occurred_at: new Date(now - r()*30*86400000).toISOString(),
    session_id:  Math.floor(r()*100).toString(),
  })).sort((a,b) => new Date(a.occurred_at)-new Date(b.occurred_at));
}

const COMPANIES = ["Apex Systems","Bolt AI","Cloudify","DeltaStack","EdgeFlow","Fusionworks",
  "Graphite IO","HorizonOps","InfinityHQ","JumpCloud","Kinetic Labs","Luminary Co",
  "MeshWorks","NexusDB","Orbital Tech","PolarSoft","QuantumHR","RocketCRM","SkyBase","TrueScale",
  "Volta Analytics","WhiteLabel","Xero Plus","Yonder Inc","Zenith Cap"];
const ROLES = ["CEO","VP Sales","CTO","Director of Ops","Head of Marketing","Founder","CRO"];
const INDUSTRIES = ["SaaS","FinTech","HealthTech","E-Commerce","Enterprise B2B","Cloud Infra","EdTech"];

function generateLeads(n=24) {
  return Array.from({length:n}, (_,i) => {
    const seed = (i+1)*137+42;
    const r = rng(seed);
    const nEvents = Math.floor(2 + r()*40);
    const events = generateLeadEvents(seed, nEvents);
    const intentFeats = computeIntentFeatures(events);
    const intentProb  = computeIntentScore(intentFeats);
    const convProb    = Math.min(1, 0.2 + r()*0.6 + intentProb*0.3);
    const final       = fusedScore(convProb, intentProb);
    return {
      id: i+1, seed,
      company: COMPANIES[i%COMPANIES.length],
      contact: ["Alex Chen","Maya Patel","Jordan Kim","Sam Rivera","Casey Wong","Riley Moore",
        "Drew Kumar","Quinn Adams","Avery Park","Taylor Lee","Morgan Liu","Sidney Cruz",
        "Jamie Torres","Blake Nguyen","Skyler Okafor","Remy Sato","Sage Brennan","Kai Petrov",
        "Noa Hassan","Finley Walsh","Zara Hughes","Lane Osei","Reese Nomura","Sasha Bell"][i%24],
      role: ROLES[i%ROLES.length],
      industry: INDUSTRIES[i%INDUSTRIES.length],
      events,
      intentFeats,
      intentProb,
      convProb,
      finalProb: final,
      finalScore: Math.round(final*100),
      intentScore: Math.round(intentProb*100),
      convScore: Math.round(convProb*100),
    };
  });
}

// ════════════════════════════════════════════════════════════════
//  DESIGN SYSTEM — Industrial intelligence terminal
//  Aesthetic: dark engineering tool meets premium analytics
//  Typefaces: IBM Plex Mono (data) + Barlow Condensed (labels)
// ════════════════════════════════════════════════════════════════

const C = {
  bg:     "#05080f",
  bg1:    "#080d18",
  bg2:    "#0c1220",
  bg3:    "#111827",
  border: "#0e1826",
  b2:     "#172034",
  text:   "#c8d8e8",
  dim:    "#3a5570",
  dim2:   "#1a2d42",
  red:    "#ff3d6b",
  amber:  "#ffcb47",
  cyan:   "#00c8ff",
  green:  "#2dffb4",
  purple: "#b388ff",
  blue:   "#4488ff",
};

const MONO = "'IBM Plex Mono','Courier New',monospace";
const COND = "'Barlow Condensed','Impact',sans-serif";
const BODY = "'Barlow Semi Condensed','Segoe UI',sans-serif";

function px(n){return `${n}px`;}

// ─── Dual progress bar ───
function DualBar({convScore, intentScore, finalScore, color}) {
  return (
    <div style={{display:"flex",flexDirection:"column",gap:3}}>
      <div style={{display:"flex",alignItems:"center",gap:6}}>
        <div style={{width:36,fontSize:8,color:C.dim,fontFamily:MONO,textAlign:"right"}}>FIT</div>
        <div style={{flex:1,height:4,background:C.bg,borderRadius:2}}>
          <div style={{height:"100%",width:`${convScore}%`,borderRadius:2,
            background:C.blue,boxShadow:`0 0 6px ${C.blue}66`,transition:"width 0.8s ease"}}/>
        </div>
        <div style={{width:24,fontSize:9,fontFamily:MONO,color:C.blue,textAlign:"right"}}>{convScore}</div>
      </div>
      <div style={{display:"flex",alignItems:"center",gap:6}}>
        <div style={{width:36,fontSize:8,color:C.dim,fontFamily:MONO,textAlign:"right"}}>INT</div>
        <div style={{flex:1,height:4,background:C.bg,borderRadius:2}}>
          <div style={{height:"100%",width:`${intentScore}%`,borderRadius:2,
            background:color,boxShadow:`0 0 6px ${color}66`,transition:"width 0.8s ease"}}/>
        </div>
        <div style={{width:24,fontSize:9,fontFamily:MONO,color,textAlign:"right"}}>{intentScore}</div>
      </div>
    </div>
  );
}

// ─── Score hexagon ───
function ScoreHex({score, color, size=72}) {
  const cx=size/2, cy=size/2, r=size/2-6;
  const pts = Array.from({length:6},(_,i)=>{
    const a=(i*60-30)*Math.PI/180;
    return `${cx+r*Math.cos(a)},${cy+r*Math.sin(a)}`;
  }).join(" ");
  const perimLen = 6*r;
  const filled   = (score/100)*perimLen;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{flexShrink:0}}>
      <polygon points={pts} fill="none" stroke={C.bg3} strokeWidth="5"/>
      <polygon points={pts} fill="none" stroke={color} strokeWidth="5"
        strokeDasharray={`${filled} ${perimLen-filled}`}
        style={{filter:`drop-shadow(0 0 8px ${color})`,transition:"all 1s ease"}}/>
      <text x={cx} y={cy+5} textAnchor="middle" fill={color}
        fontSize={size>60?18:13} fontWeight="900" fontFamily={MONO}>{score}</text>
    </svg>
  );
}

// ─── Intent signal pill ───
function SignalPill({event, days_ago, decay}) {
  const cfg = EVENT_CATALOG[event]||{tier:"L",label:event,icon:"•"};
  const color = TIER_COLOR[cfg.tier];
  return (
    <div style={{display:"inline-flex",alignItems:"center",gap:5,padding:"3px 10px",borderRadius:20,
      background:`${color}12`,border:`1px solid ${color}33`,flexShrink:0,
      opacity:Math.max(0.4,decay)}}>
      <span style={{fontSize:11}}>{cfg.icon}</span>
      <span style={{fontSize:9,fontFamily:BODY,color,fontWeight:600}}>{cfg.label}</span>
      {days_ago!==undefined&&<span style={{fontSize:8,color:C.dim,fontFamily:MONO}}>{days_ago.toFixed(0)}d</span>}
    </div>
  );
}

// ─── Sequence badge ───
function SeqBadge({label, active}) {
  return (
    <div style={{display:"flex",alignItems:"center",gap:6,padding:"5px 10px",
      background:active?`${C.green}10`:C.bg2,borderRadius:6,
      border:`1px solid ${active?C.green:C.dim2}`,transition:"all 0.3s"}}>
      <div style={{width:6,height:6,borderRadius:"50%",flexShrink:0,
        background:active?C.green:C.dim2,boxShadow:active?`0 0 8px ${C.green}`:""}}/>
      <span style={{fontSize:9,fontFamily:MONO,color:active?C.green:C.dim,fontWeight:active?700:400}}>
        {label}
      </span>
    </div>
  );
}

// ─── Velocity gauge ───
function VelocityGauge({value, max=5, label, color}) {
  const pct = Math.min(100,(value/max)*100);
  const needleAngle = -135 + (pct/100)*270;
  const cx=40, cy=40, r=28;
  const arcStart = {x:cx+r*Math.cos(-135*Math.PI/180), y:cy+r*Math.sin(-135*Math.PI/180)};
  const arcEnd   = {x:cx+r*Math.cos(135*Math.PI/180),  y:cy+r*Math.sin(135*Math.PI/180)};
  const nAngle = needleAngle*Math.PI/180;
  const nx = cx+20*Math.cos(nAngle), ny = cy+20*Math.sin(nAngle);

  return (
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:2}}>
      <svg width="80" height="60" viewBox="0 0 80 60">
        <path d={`M ${arcStart.x},${arcStart.y} A ${r},${r} 0 1 1 ${arcEnd.x},${arcEnd.y}`}
          fill="none" stroke={C.bg3} strokeWidth="5" strokeLinecap="round"/>
        <path d={`M ${arcStart.x},${arcStart.y} A ${r},${r} 0 1 1 ${arcEnd.x},${arcEnd.y}`}
          fill="none" stroke={color} strokeWidth="5" strokeLinecap="round"
          strokeDasharray={`${pct/100*5.76*r} 999`}
          style={{filter:`drop-shadow(0 0 5px ${color})`}}/>
        <line x1={cx} y1={cy} x2={nx} y2={ny} stroke={color} strokeWidth="2" strokeLinecap="round"/>
        <circle cx={cx} cy={cy} r={3} fill={color}/>
        <text x={cx} y={58} textAnchor="middle" fill={color}
          fontSize="11" fontWeight="900" fontFamily={MONO}>{value.toFixed(1)}×</text>
      </svg>
      <div style={{fontSize:8,color:C.dim,fontFamily:MONO,letterSpacing:"0.1em"}}>{label}</div>
    </div>
  );
}

// ─── Timeline ───
function EventTimeline({events}) {
  const sorted = [...events].sort((a,b)=>new Date(b.occurred_at)-new Date(a.occurred_at));
  const now = Date.now();
  return (
    <div style={{display:"flex",flexDirection:"column",gap:0}}>
      {sorted.slice(0,12).map((e,i)=>{
        const cfg = EVENT_CATALOG[e.event_type]||{tier:"L",label:e.event_type,icon:"•"};
        const color = TIER_COLOR[cfg.tier];
        const daysAgo = ((now - new Date(e.occurred_at).getTime())/86400000).toFixed(0);
        const decay   = recencyDecay(+daysAgo);
        return (
          <div key={i} style={{display:"flex",gap:10,position:"relative",padding:"6px 0"}}>
            {i<sorted.length-1&&<div style={{position:"absolute",left:9,top:26,width:1,height:"calc(100% - 14px)",background:C.b2}}/>}
            <div style={{width:18,height:18,borderRadius:4,flexShrink:0,
              background:`${color}18`,border:`1px solid ${color}44`,
              display:"flex",alignItems:"center",justifyContent:"center",fontSize:9}}>{cfg.icon}</div>
            <div style={{flex:1}}>
              <div style={{fontSize:10,fontFamily:BODY,fontWeight:600,color:C.text,opacity:Math.max(0.4,decay)}}>{cfg.label}</div>
              <div style={{fontSize:8,fontFamily:MONO,color:C.dim}}>{daysAgo}d ago</div>
            </div>
            <div style={{padding:"1px 7px",borderRadius:10,background:`${color}14`,
              border:`1px solid ${color}33`,fontSize:8,fontFamily:MONO,color,flexShrink:0}}>
              +{cfg.w}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Intent heatmap (tier breakdown arc) ───
function IntentArc({high, medium, low}) {
  const total = high+medium+low || 1;
  const hPct=high/total, mPct=medium/total, lPct=low/total;
  const cx=60,cy=60,r=40,strokeW=14;
  const circum=2*Math.PI*r;
  const hLen=circum*hPct, mLen=circum*mPct, lLen=circum*lPct;

  return (
    <svg width="120" height="80" viewBox="0 0 120 80">
      <circle cx={cx} cy={cy+10} r={r} fill="none" stroke={C.bg3} strokeWidth={strokeW}/>
      {/* Low */}
      <circle cx={cx} cy={cy+10} r={r} fill="none" stroke={C.dim2} strokeWidth={strokeW}
        strokeDasharray={`${lLen} ${circum-lLen}`}
        strokeDashoffset={circum/4} strokeLinecap="butt"/>
      {/* Medium */}
      <circle cx={cx} cy={cy+10} r={r} fill="none" stroke={C.amber} strokeWidth={strokeW}
        strokeDasharray={`${mLen} ${circum-mLen}`}
        strokeDashoffset={circum/4-lLen} strokeLinecap="butt"/>
      {/* High */}
      <circle cx={cx} cy={cy+10} r={r} fill="none" stroke={C.red} strokeWidth={strokeW}
        strokeDasharray={`${hLen} ${circum-hLen}`}
        strokeDashoffset={circum/4-lLen-mLen} strokeLinecap="butt"
        style={{filter:`drop-shadow(0 0 6px ${C.red})`}}/>
      <text x={cx} y={cy+14} textAnchor="middle" fill={C.red}
        fontSize="13" fontWeight="900" fontFamily={MONO}>{(hPct*100).toFixed(0)}%</text>
      <text x={cx} y={cy+24} textAnchor="middle" fill={C.dim}
        fontSize="7" fontFamily={MONO}>HIGH</text>
    </svg>
  );
}

// ─── Lead row in list ───
function LeadRow({lead, active, onClick}) {
  const getColor = (s) => s>=85?C.red:s>=70?C.amber:s>=50?C.cyan:s>=30?C.blue:C.dim;
  const color = getColor(lead.finalScore);

  return (
    <div onClick={()=>onClick(lead)} style={{
      display:"flex",alignItems:"center",gap:10,padding:"10px 12px",
      borderRadius:7,cursor:"pointer",
      background:active?C.bg3:C.bg1,
      border:`1px solid ${active?color:C.border}`,
      boxShadow:active?`0 0 18px ${color}1a`:"none",
      transition:"all 0.15s",
    }}>
      <ScoreHex score={lead.finalScore} color={color} size={54}/>
      <div style={{flex:1,minWidth:0}}>
        <div style={{fontFamily:COND,fontSize:13,fontWeight:700,color:C.text,letterSpacing:"0.02em",
          overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{lead.company}</div>
        <div style={{fontSize:8,fontFamily:MONO,color:C.dim,marginBottom:4}}>{lead.role}</div>
        <DualBar convScore={lead.convScore} intentScore={lead.intentScore} color={color}/>
      </div>
    </div>
  );
}

// ─── DETAIL PANEL ───
function DetailPanel({lead}) {
  if (!lead) return (
    <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"100%",
      flexDirection:"column",gap:8,color:C.dim2}}>
      <div style={{fontSize:40}}>⟵</div>
      <div style={{fontSize:11,fontFamily:MONO}}>SELECT A LEAD</div>
    </div>
  );

  const getColor = (s) => s>=85?C.red:s>=70?C.amber:s>=50?C.cyan:s>=30?C.blue:C.dim;
  const color = getColor(lead.finalScore);
  const f = lead.intentFeats;

  // Top signals for this lead
  const now = Date.now();
  const topSignals = [...lead.events]
    .filter(e=>EVENT_CATALOG[e.event_type]?.tier!=="L")
    .map(e=>({
      ...e,
      cfg: EVENT_CATALOG[e.event_type],
      daysAgo: (now-new Date(e.occurred_at).getTime())/86400000,
    }))
    .sort((a,b)=>b.cfg.w*recencyDecay(a.daysAgo) - a.cfg.w*recencyDecay(b.daysAgo))
    .slice(0,8);

  const tier = lead.finalScore>=85?"S":lead.finalScore>=70?"A":lead.finalScore>=50?"B":lead.finalScore>=30?"C":"D";
  const actions = {S:"Call Immediately",A:"Schedule Demo",B:"Send Case Study",C:"Nurture Campaign",D:"Retarget Later"};
  const slas    = {S:"< 1 hour",A:"< 4 hours",B:"< 24 hours",C:"< 72 hours",D:"Next week"};

  return (
    <div style={{overflowY:"auto",height:"100%",padding:20}}>
      {/* Header */}
      <div style={{display:"flex",gap:16,marginBottom:20,alignItems:"flex-start"}}>
        <ScoreHex score={lead.finalScore} color={color} size={90}/>
        <div>
          <div style={{fontFamily:COND,fontSize:22,fontWeight:800,color:C.text,
            letterSpacing:"0.02em",lineHeight:1}}>{lead.company}</div>
          <div style={{fontSize:11,fontFamily:MONO,color:C.dim,marginTop:4,marginBottom:10}}>
            {lead.contact} · {lead.role} · {lead.industry}
          </div>
          <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
            <div style={{display:"inline-flex",alignItems:"center",gap:7,padding:"5px 14px",
              background:`${color}18`,border:`1px solid ${color}55`,borderRadius:24,
              fontSize:11,fontWeight:700,color,boxShadow:`0 0 14px ${color}33`,fontFamily:BODY}}>
              {tier==="S"?"🔥":tier==="A"?"📅":tier==="B"?"📧":tier==="C"?"💧":"❄️"} {actions[tier]}
            </div>
            <div style={{display:"inline-flex",padding:"5px 12px",background:C.bg3,
              border:`1px solid ${C.b2}`,borderRadius:24,fontSize:10,color:C.dim,fontFamily:MONO}}>
              SLA {slas[tier]}
            </div>
          </div>
        </div>
      </div>

      {/* Score fusion bar */}
      <div style={{background:C.bg1,border:`1px solid ${C.border}`,borderRadius:10,padding:16,marginBottom:14}}>
        <div style={{fontSize:9,fontFamily:MONO,color:C.dim2,letterSpacing:"0.14em",fontWeight:700,marginBottom:12}}>
          SCORE FUSION  ·  60% FIT + 40% INTENT
        </div>
        <div style={{display:"flex",gap:16,alignItems:"center",marginBottom:12}}>
          {[
            ["FINAL","finalScore",color],
            ["FIT","convScore",C.blue],
            ["INTENT","intentScore",C.green],
          ].map(([l,k,c])=>(
            <div key={l} style={{textAlign:"center"}}>
              <div style={{fontSize:8,fontFamily:MONO,color:C.dim,letterSpacing:"0.1em"}}>{l}</div>
              <div style={{fontSize:26,fontWeight:900,fontFamily:MONO,color:c,lineHeight:1}}>{lead[k]}</div>
            </div>
          ))}
          <div style={{flex:1,height:1,background:C.b2,marginLeft:8}}/>
          <div style={{display:"flex",gap:10,alignItems:"center"}}>
            <span style={{fontSize:9,fontFamily:MONO,color:C.dim}}>0.6×</span>
            <div style={{width:28,height:12,background:`${C.blue}33`,border:`1px solid ${C.blue}55`,borderRadius:3,
              display:"flex",alignItems:"center",justifyContent:"center"}}>
              <span style={{fontSize:7,color:C.blue,fontFamily:MONO}}>FIT</span>
            </div>
            <span style={{fontSize:9,fontFamily:MONO,color:C.dim}}>+  0.4×</span>
            <div style={{width:32,height:12,background:`${C.green}33`,border:`1px solid ${C.green}55`,borderRadius:3,
              display:"flex",alignItems:"center",justifyContent:"center"}}>
              <span style={{fontSize:7,color:C.green,fontFamily:MONO}}>INT</span>
            </div>
          </div>
        </div>
        <div style={{height:8,background:C.bg,borderRadius:4,position:"relative",overflow:"hidden"}}>
          <div style={{position:"absolute",left:0,top:0,height:"100%",
            width:`${lead.convScore*0.60}%`,
            background:`linear-gradient(90deg,${C.blue},${C.blue}aa)`}}/>
          <div style={{position:"absolute",left:`${lead.convScore*0.60}%`,top:0,height:"100%",
            width:`${lead.intentScore*0.40}%`,
            background:`linear-gradient(90deg,${C.green}aa,${C.green})`}}/>
        </div>
        <div style={{display:"flex",justifyContent:"space-between",marginTop:4}}>
          <span style={{fontSize:8,fontFamily:MONO,color:C.blue}}>Fit {lead.convScore}pts × 0.60 = {Math.round(lead.convScore*0.60)}</span>
          <span style={{fontSize:8,fontFamily:MONO,color:C.green}}>Intent {lead.intentScore}pts × 0.40 = {Math.round(lead.intentScore*0.40)}</span>
        </div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1.2fr 0.8fr",gap:12,marginBottom:12}}>
        {/* Intent signals */}
        <div style={{background:C.bg1,border:`1px solid ${C.border}`,borderRadius:10,padding:14}}>
          <div style={{fontSize:9,fontFamily:MONO,color:C.dim2,letterSpacing:"0.14em",fontWeight:700,marginBottom:12}}>
            TOP INTENT SIGNALS
          </div>
          <div style={{display:"flex",flexWrap:"wrap",gap:5,marginBottom:10}}>
            {topSignals.map((e,i)=>(
              <SignalPill key={i} event={e.event_type}
                days_ago={e.daysAgo} decay={recencyDecay(e.daysAgo)}/>
            ))}
          </div>
          <div style={{height:1,background:C.border,marginBottom:10}}/>
          <div style={{fontSize:9,fontFamily:MONO,color:C.dim2,letterSpacing:"0.14em",fontWeight:700,marginBottom:8}}>
            BEHAVIOR SEQUENCES
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:5}}>
            <SeqBadge label="blog→pricing"   active={f.seqs.blog_to_pricing}/>
            <SeqBadge label="pricing→demo"   active={f.seqs.pricing_to_demo}/>
            <SeqBadge label="study→pricing"  active={f.seqs.case_study_to_pricing}/>
            <SeqBadge label="trial→pricing"  active={f.seqs.trial_to_pricing}/>
            <SeqBadge label="3× pricing"     active={f.seqs.multi_session_pricing}/>
          </div>
        </div>

        {/* Velocity + breakdown */}
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          <div style={{background:C.bg1,border:`1px solid ${C.border}`,borderRadius:10,padding:14}}>
            <div style={{fontSize:9,fontFamily:MONO,color:C.dim2,letterSpacing:"0.14em",fontWeight:700,marginBottom:10}}>
              VELOCITY
            </div>
            <div style={{display:"flex",justifyContent:"space-around"}}>
              <VelocityGauge value={f.engVelocity}  max={5} label="ENGAGE" color={C.cyan}/>
              <VelocityGauge value={f.hiVelocity}   max={5} label="INTENT" color={C.red}/>
            </div>
          </div>
          <div style={{background:C.bg1,border:`1px solid ${C.border}`,borderRadius:10,padding:14}}>
            <div style={{fontSize:9,fontFamily:MONO,color:C.dim2,letterSpacing:"0.14em",fontWeight:700,marginBottom:6}}>
              SIGNAL TIERS
            </div>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <IntentArc high={lead.events.filter(e=>EVENT_CATALOG[e.event_type]?.tier==="H").length}
                medium={lead.events.filter(e=>EVENT_CATALOG[e.event_type]?.tier==="M").length}
                low={lead.events.filter(e=>EVENT_CATALOG[e.event_type]?.tier==="L").length}/>
              <div style={{display:"flex",flexDirection:"column",gap:5}}>
                {[["HIGH",C.red,f.highPct],["MED",C.amber,f.medPct],["LOW",C.dim,f.lowPct]].map(([l,c,p])=>(
                  <div key={l} style={{display:"flex",gap:6,alignItems:"center"}}>
                    <div style={{width:6,height:6,borderRadius:"50%",background:c}}/>
                    <span style={{fontSize:8,fontFamily:MONO,color:c}}>{l}</span>
                    <span style={{fontSize:9,fontFamily:MONO,color:C.dim}}>{(p*100).toFixed(0)}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Event timeline */}
      <div style={{background:C.bg1,border:`1px solid ${C.border}`,borderRadius:10,padding:14}}>
        <div style={{fontSize:9,fontFamily:MONO,color:C.dim2,letterSpacing:"0.14em",fontWeight:700,marginBottom:10}}>
          EVENT TIMELINE  ·  {lead.events.length} EVENTS
        </div>
        <EventTimeline events={lead.events}/>
      </div>
    </div>
  );
}

// ─── Intent radar/scatter for overview ───
function IntentScatter({leads, onSelect, selected}) {
  const W=380, H=280;
  const pad=30;
  const iW=W-2*pad, iH=H-2*pad;
  const getColor = s=>s>=85?C.red:s>=70?C.amber:s>=50?C.cyan:s>=30?C.blue:C.dim;

  return (
    <div style={{background:C.bg1,border:`1px solid ${C.border}`,borderRadius:10,padding:14}}>
      <div style={{fontSize:9,fontFamily:MONO,color:C.dim2,letterSpacing:"0.14em",fontWeight:700,marginBottom:10}}>
        INTENT vs FIT SCATTER  (size = events)
      </div>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{overflow:"visible"}}>
        {/* Grid */}
        {[0,25,50,75,100].map(v=>(
          <g key={v}>
            <line x1={pad} y1={pad+iH*(1-v/100)} x2={pad+iW} y2={pad+iH*(1-v/100)}
              stroke={C.b2} strokeWidth="0.5"/>
            <line x1={pad+iW*v/100} y1={pad} x2={pad+iW*v/100} y2={pad+iH}
              stroke={C.b2} strokeWidth="0.5"/>
            <text x={pad-4} y={pad+iH*(1-v/100)+3} textAnchor="end"
              fill={C.dim} fontSize="7" fontFamily={MONO}>{v}</text>
            <text x={pad+iW*v/100} y={pad+iH+12} textAnchor="middle"
              fill={C.dim} fontSize="7" fontFamily={MONO}>{v}</text>
          </g>
        ))}
        {/* Axis labels */}
        <text x={pad+iW/2} y={H-2} textAnchor="middle" fill={C.dim} fontSize="8" fontFamily={MONO}>FIT SCORE →</text>
        <text x={8} y={pad+iH/2} textAnchor="middle" fill={C.dim} fontSize="8" fontFamily={MONO}
          transform={`rotate(-90,8,${pad+iH/2})`}>INTENT →</text>

        {/* Quadrant labels */}
        <text x={pad+iW*0.82} y={pad+14} fill={C.red} fontSize="8" fontFamily={MONO} opacity="0.6">HIGH FIT</text>
        <text x={pad+iW*0.82} y={pad+24} fill={C.red} fontSize="8" fontFamily={MONO} opacity="0.6">HIGH INTENT</text>

        {/* Leads */}
        {leads.map(l=>{
          const x = pad + (l.convScore/100)*iW;
          const y = pad + iH - (l.intentScore/100)*iH;
          const r = Math.max(4, Math.min(12, l.events.length/4));
          const color = getColor(l.finalScore);
          const isSelected = selected?.id===l.id;
          return (
            <g key={l.id} onClick={()=>onSelect(l)} style={{cursor:"pointer"}}>
              <circle cx={x} cy={y} r={r+3} fill="transparent"/>
              <circle cx={x} cy={y} r={r} fill={`${color}33`} stroke={color}
                strokeWidth={isSelected?2:1}
                style={{filter:isSelected?`drop-shadow(0 0 8px ${color})`:""}}/>
              {isSelected&&<text x={x} y={y-r-3} textAnchor="middle" fill={color}
                fontSize="7" fontFamily={MONO}>{l.company.split(" ")[0]}</text>}
            </g>
          );
        })}
      </svg>
    </div>
  );
}

// ────────────────────────────────────────────
//  MAIN APP
// ────────────────────────────────────────────

const SCORE_TIERS_DEF=[
  {t:"S",min:85,label:"CRITICAL — Call Now",   color:C.red,   sla:"<1h"},
  {t:"A",min:70,label:"HOT — Schedule Demo",   color:C.amber, sla:"<4h"},
  {t:"B",min:50,label:"WARM — Send Case Study",color:C.cyan,  sla:"<24h"},
  {t:"C",min:30,label:"COLD — Nurture",        color:C.blue,  sla:"<72h"},
  {t:"D",min:0, label:"DEAD — Retarget",       color:C.dim,   sla:"1 week"},
];

export default function IntentDashboard() {
  const [leads,   setLeads]   = useState([]);
  const [sel,     setSel]     = useState(null);
  const [filter,  setFilter]  = useState("ALL");
  const [sort,    setSort]    = useState("final");
  const [tick,    setTick]    = useState(0);
  const [tab,     setTab]     = useState("leads");  // leads | overview | model

  useEffect(()=>{
    const l = generateLeads(24);
    setLeads(l);
    setSel(l[0]);
  },[]);

  // Live pulse
  useEffect(()=>{const t=setInterval(()=>setTick(x=>x+1),3000);return()=>clearInterval(t);},[]);

  const getColor = s=>s>=85?C.red:s>=70?C.amber:s>=50?C.cyan:s>=30?C.blue:C.dim;
  const getTier  = s=>s>=85?"S":s>=70?"A":s>=50?"B":s>=30?"C":"D";

  const filtered = leads.filter(l=>filter==="ALL"||getTier(l.finalScore)===filter)
    .sort((a,b)=>{
      if(sort==="final")  return b.finalScore-a.finalScore;
      if(sort==="intent") return b.intentScore-a.intentScore;
      if(sort==="fit")    return b.convScore-a.convScore;
      return 0;
    });

  const tierCounts = {S:0,A:0,B:0,C:0,D:0};
  leads.forEach(l=>tierCounts[getTier(l.finalScore)]++);
  const avgIntent = leads.length?(leads.reduce((s,l)=>s+l.intentScore,0)/leads.length).toFixed(0):0;
  const highIntent = leads.filter(l=>l.intentScore>=70).length;

  return (
    <div style={{height:"100vh",display:"flex",flexDirection:"column",
      background:C.bg,fontFamily:MONO,color:C.text,fontSize:12}}>

      {/* ── TOP BAR ── */}
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",
        padding:"0 18px",height:50,background:C.bg1,borderBottom:`1px solid ${C.border}`,flexShrink:0}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <div style={{width:32,height:32,borderRadius:8,
            background:"linear-gradient(135deg,#ff3d6b,#ff8c00)",
            display:"flex",alignItems:"center",justifyContent:"center",
            fontSize:17,boxShadow:"0 0 20px #ff3d6b44"}}>⚡</div>
          <div>
            <div style={{fontFamily:COND,fontSize:14,fontWeight:800,letterSpacing:"0.08em",color:C.text}}>
              BUYER INTENT ENGINE
            </div>
            <div style={{fontSize:7,color:C.dim,letterSpacing:"0.18em"}}>
              DUAL-MODEL SCORING · SEQUENCE DETECTION · REAL-TIME FUSION
            </div>
          </div>
        </div>

        {/* Nav */}
        <div style={{display:"flex",gap:2}}>
          {[["leads","📋 Leads"],["overview","📊 Overview"],["model","⚙️ Model"]].map(([k,l])=>(
            <button key={k} onClick={()=>setTab(k)} style={{
              background:tab===k?C.bg3:"transparent",
              border:`1px solid ${tab===k?C.b2:"transparent"}`,
              color:tab===k?C.green:C.dim,padding:"5px 14px",borderRadius:5,
              cursor:"pointer",fontSize:9,fontFamily:MONO,fontWeight:700,
              letterSpacing:"0.08em",transition:"all 0.15s"}}>
              {l}
            </button>
          ))}
        </div>

        {/* Live stats */}
        <div style={{display:"flex",gap:18,alignItems:"center"}}>
          {[["HOT LEADS",highIntent,C.red],["AVG INTENT",avgIntent,C.cyan],
            ["TIER S",tierCounts.S,C.red]].map(([l,v,c])=>(
            <div key={l} style={{textAlign:"right"}}>
              <div style={{fontSize:7,color:C.dim,letterSpacing:"0.12em"}}>{l}</div>
              <div style={{fontSize:16,fontWeight:900,color:c,fontFamily:MONO}}>{v}</div>
            </div>
          ))}
          <div style={{display:"flex",alignItems:"center",gap:5,padding:"4px 10px",
            background:C.bg3,borderRadius:5,border:`1px solid ${C.b2}`}}>
            <div style={{width:5,height:5,borderRadius:"50%",background:C.red,
              boxShadow:`0 0 ${tick%2===0?8:4}px ${C.red}`}}/>
            <span style={{fontSize:7,color:C.red,fontWeight:800,letterSpacing:"0.12em"}}>LIVE</span>
          </div>
        </div>
      </div>

      {/* ── BODY ── */}
      <div style={{flex:1,overflow:"hidden",display:"flex"}}>

        {tab==="leads"&&(
          <>
            {/* List panel */}
            <div style={{width:290,flexShrink:0,borderRight:`1px solid ${C.border}`,
              display:"flex",flexDirection:"column"}}>
              {/* Filters */}
              <div style={{padding:"7px 10px",borderBottom:`1px solid ${C.border}`,
                display:"flex",gap:3,flexWrap:"wrap",alignItems:"center"}}>
                {["ALL","S","A","B","C","D"].map(t=>{
                  const def=SCORE_TIERS_DEF.find(d=>d.t===t);
                  const active=filter===t;
                  const c=def?.color||C.green;
                  return <button key={t} onClick={()=>setFilter(t)} style={{
                    padding:"2px 8px",borderRadius:4,cursor:"pointer",fontFamily:MONO,
                    fontSize:8,fontWeight:800,letterSpacing:"0.08em",
                    background:active?`${c}18`:"transparent",
                    border:`1px solid ${active?`${c}55`:C.border}`,
                    color:active?c:C.dim2}}>{t}</button>;
                })}
                <div style={{marginLeft:"auto",display:"flex",gap:2}}>
                  {[["final","FIN"],["intent","INT"],["fit","FIT"]].map(([k,l])=>(
                    <button key={k} onClick={()=>setSort(k)} style={{
                      padding:"2px 6px",borderRadius:3,cursor:"pointer",fontFamily:MONO,
                      fontSize:7,fontWeight:800,
                      background:sort===k?C.bg3:"transparent",
                      border:`1px solid ${sort===k?C.b2:"transparent"}`,
                      color:sort===k?C.green:C.dim2}}>{l}</button>
                  ))}
                </div>
              </div>
              <div style={{flex:1,overflowY:"auto",padding:7,display:"flex",flexDirection:"column",gap:5}}>
                {filtered.map(l=>(
                  <LeadRow key={l.id} lead={l} active={sel?.id===l.id} onClick={setSel}/>
                ))}
              </div>
            </div>

            {/* Detail panel */}
            <div style={{flex:1,overflow:"hidden"}}>
              <DetailPanel lead={sel}/>
            </div>
          </>
        )}

        {tab==="overview"&&(
          <div style={{flex:1,padding:20,overflowY:"auto"}}>
            {/* Stats row */}
            <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:10,marginBottom:16}}>
              {[
                ["TOTAL LEADS",leads.length,C.text],
                ["AVG INTENT",avgIntent,C.red],
                ["AVG FIT",leads.length?(leads.reduce((s,l)=>s+l.convScore,0)/leads.length).toFixed(0):0,C.blue],
                ["SEQUENCES DETECTED",leads.filter(l=>Object.values(l.intentFeats.seqs).some(Boolean)).length,C.green],
                ["TIER S+A",tierCounts.S+tierCounts.A,C.amber],
              ].map(([l,v,c])=>(
                <div key={l} style={{background:C.bg1,border:`1px solid ${C.border}`,borderRadius:10,padding:"12px 16px"}}>
                  <div style={{fontSize:8,color:C.dim2,letterSpacing:"0.12em",fontWeight:700,marginBottom:4}}>{l}</div>
                  <div style={{fontSize:24,fontWeight:900,fontFamily:MONO,color:c,lineHeight:1}}>{v}</div>
                </div>
              ))}
            </div>

            <div style={{display:"grid",gridTemplateColumns:"auto 1fr",gap:14,marginBottom:14}}>
              <IntentScatter leads={leads} onSelect={setSel} selected={sel}/>
              {/* Tier distribution */}
              <div style={{background:C.bg1,border:`1px solid ${C.border}`,borderRadius:10,padding:16}}>
                <div style={{fontSize:9,fontFamily:MONO,color:C.dim2,letterSpacing:"0.14em",fontWeight:700,marginBottom:14}}>
                  TIER DISTRIBUTION
                </div>
                {SCORE_TIERS_DEF.map(d=>{
                  const count = tierCounts[d.t]||0;
                  const pct = leads.length?count/leads.length:0;
                  return (
                    <div key={d.t} style={{marginBottom:12}}>
                      <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                        <div style={{display:"flex",alignItems:"center",gap:8}}>
                          <div style={{width:20,height:20,borderRadius:5,background:`${d.color}18`,
                            border:`1px solid ${d.color}44`,display:"flex",alignItems:"center",
                            justifyContent:"center",fontSize:9,fontWeight:900,color:d.color,fontFamily:MONO}}>
                            {d.t}
                          </div>
                          <span style={{fontSize:10,fontFamily:BODY,color:C.text}}>{d.label}</span>
                        </div>
                        <span style={{fontSize:11,fontFamily:MONO,color:d.color,fontWeight:700}}>{count}</span>
                      </div>
                      <div style={{height:5,background:C.bg,borderRadius:3}}>
                        <div style={{height:"100%",width:`${pct*100}%`,borderRadius:3,background:d.color,
                          boxShadow:`0 0 6px ${d.color}55`,transition:"width 0.8s ease"}}/>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Sequence stats */}
            <div style={{background:C.bg1,border:`1px solid ${C.border}`,borderRadius:10,padding:16}}>
              <div style={{fontSize:9,fontFamily:MONO,color:C.dim2,letterSpacing:"0.14em",fontWeight:700,marginBottom:12}}>
                DETECTED PURCHASE SEQUENCES
              </div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:10}}>
                {[
                  ["blog → pricing",    "blog_to_pricing"],
                  ["pricing → demo",    "pricing_to_demo"],
                  ["study → pricing",   "case_study_to_pricing"],
                  ["trial → pricing",   "trial_to_pricing"],
                  ["3× pricing",        "multi_session_pricing"],
                ].map(([label,key])=>{
                  const count = leads.filter(l=>l.intentFeats.seqs[key]).length;
                  const color = count>=5?C.red:count>=3?C.amber:count>=1?C.cyan:C.dim2;
                  return (
                    <div key={key} style={{background:C.bg2,borderRadius:8,padding:"12px 14px",
                      border:`1px solid ${count>0?color+"33":C.border}`}}>
                      <div style={{fontSize:20,fontWeight:900,fontFamily:MONO,color,lineHeight:1}}>{count}</div>
                      <div style={{fontSize:9,color:C.dim,marginTop:4,fontFamily:MONO}}>{label}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {tab==="model"&&(
          <div style={{flex:1,padding:20,overflowY:"auto"}}>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
              {/* Architecture */}
              <div style={{background:C.bg1,border:`1px solid ${C.border}`,borderRadius:10,padding:18}}>
                <div style={{fontSize:9,fontFamily:MONO,color:C.dim2,letterSpacing:"0.14em",fontWeight:700,marginBottom:16}}>
                  DUAL MODEL ARCHITECTURE
                </div>
                {[
                  {label:"Raw Events",color:C.dim,desc:"HubSpot / Segment / Website"},
                  {label:"Intent Feature Engine",color:C.cyan,desc:"35 behavioral features, recency decay"},
                  {label:"Intent Model (XGBoost)",color:C.red,desc:"AUC 0.87 · trained on behavior only"},
                  null,
                  {label:"Firmographic Features",color:C.dim,desc:"Company size, role, industry, source"},
                  {label:"Conversion Model (Ensemble)",color:C.blue,desc:"XGB 60% + RF 30% + LR 10%"},
                  null,
                  {label:"Score Aggregator",color:C.green,desc:"0.60 × fit + 0.40 × intent"},
                  {label:"Final Score + Tier + Action",color:C.amber,desc:"API response < 50ms"},
                ].map((step,i)=>{
                  if (!step) return <div key={i} style={{display:"flex",gap:8,marginBottom:6}}>
                    <div style={{width:16}}/>
                    <div style={{height:20,borderLeft:`1px dashed ${C.b2}`}}/>
                  </div>;
                  return (
                    <div key={i} style={{display:"flex",gap:10,marginBottom:8,alignItems:"center"}}>
                      <div style={{width:4,height:32,borderRadius:2,background:step.color,
                        boxShadow:`0 0 6px ${step.color}55`,flexShrink:0}}/>
                      <div>
                        <div style={{fontSize:11,fontWeight:700,fontFamily:BODY,color:step.color}}>{step.label}</div>
                        <div style={{fontSize:8,fontFamily:MONO,color:C.dim}}>{step.desc}</div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div style={{display:"flex",flexDirection:"column",gap:12}}>
                {/* Event weights table */}
                <div style={{background:C.bg1,border:`1px solid ${C.border}`,borderRadius:10,padding:16,flex:1}}>
                  <div style={{fontSize:9,fontFamily:MONO,color:C.dim2,letterSpacing:"0.14em",fontWeight:700,marginBottom:12}}>
                    EVENT WEIGHT TABLE
                  </div>
                  <div style={{display:"flex",flexDirection:"column",gap:4,maxHeight:260,overflowY:"auto"}}>
                    {Object.entries(EVENT_CATALOG).map(([k,cfg])=>{
                      const color=TIER_COLOR[cfg.tier];
                      const barW = (cfg.w/50)*100;
                      return (
                        <div key={k} style={{display:"flex",alignItems:"center",gap:8}}>
                          <div style={{width:12,fontSize:9,textAlign:"center"}}>{cfg.icon}</div>
                          <div style={{width:130,fontSize:8,fontFamily:BODY,color:C.dim,
                            overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{cfg.label}</div>
                          <div style={{flex:1,height:4,background:C.bg,borderRadius:2}}>
                            <div style={{height:"100%",width:`${barW}%`,borderRadius:2,background:color,
                              boxShadow:`0 0 4px ${color}44`}}/>
                          </div>
                          <div style={{width:22,fontSize:9,fontFamily:MONO,color,textAlign:"right",fontWeight:700}}>
                            +{cfg.w}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* AUC progression */}
                <div style={{background:C.bg1,border:`1px solid ${C.border}`,borderRadius:10,padding:16}}>
                  <div style={{fontSize:9,fontFamily:MONO,color:C.dim2,letterSpacing:"0.14em",fontWeight:700,marginBottom:12}}>
                    AUC IMPROVEMENT LADDER
                  </div>
                  {[
                    ["Basic (firmographics only)",   0.65, C.dim2],
                    ["+ Feature engineering",        0.72, C.dim],
                    ["+ Behavioral signals",         0.80, C.blue],
                    ["+ Intent model fusion",        0.87, C.cyan],
                    ["+ Sequence detection",         0.89, C.green],
                  ].map(([l,auc,c],i)=>(
                    <div key={i} style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
                      <div style={{flex:1,fontSize:9,fontFamily:BODY,color:C.dim}}>{l}</div>
                      <div style={{width:120,height:5,background:C.bg,borderRadius:3}}>
                        <div style={{height:"100%",width:`${(auc-0.5)/0.5*100}%`,borderRadius:3,
                          background:c,boxShadow:`0 0 5px ${c}55`}}/>
                      </div>
                      <div style={{width:36,fontSize:10,fontFamily:MONO,fontWeight:800,color:c,textAlign:"right"}}>
                        {auc.toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* FOOTER */}
      <div style={{flexShrink:0,height:22,background:C.bg,borderTop:`1px solid ${C.border}`,
        display:"flex",alignItems:"center",gap:20,padding:"0 16px",
        fontSize:7,color:C.dim2,letterSpacing:"0.1em"}}>
        <span>INTENT ENGINE: 25 event types · 3 tiers · recency decay λ=14d</span>
        <span>FEATURES: 35 behavioral features + 5 sequence flags</span>
        <span>FUSION: 0.60 × conversion + 0.40 × intent</span>
        <span>SEQUENCE DETECTOR: O(n) scan, gap=20 events</span>
        <span style={{marginLeft:"auto"}}>LeadScore Pro — Buyer Intent Layer v1.0</span>
      </div>
    </div>
  );
}
